import { getPartyPFSStats } from "./math.js";

export function registerEnrichers() {

    CONFIG.TextEditor.enrichers.push({
        pattern: /@WFT\[(.*?)\]/g,
        enricher: async (match, options) => {
            const params = {};
            match[1].split("|").forEach(part => {
                const colonIdx = part.indexOf(":");
                if (colonIdx !== -1) {
                    const key = part.substring(0, colonIdx).trim();
                    const value = part.substring(colonIdx + 1).trim();
                    if (key && value) params[key] = value;
                }
            });

            const baseLevel = parseInt(params.baseLevel) || game.settings.get("wolfies-foundry-tools", "scenarioBaseLevel");
            const { cp, tier, bracket, playerCount } = getPartyPFSStats(baseLevel);
            const span = document.createElement("span");
            span.classList.add("pfs-dynamic-value");

            const wrapStyle = "white-space: normal; word-break: break-word; height: auto; display: inline-block; line-height: 1.2; padding-top: 2px; padding-bottom: 2px;";

            if (params.type === "dc") {
                let buttonLabels = [];
                let isMulti = "low_0" in params || "high_0" in params || "skill_0" in params;

                let checkConfig = {
                    secret: params.secret === "true",
                    skills: []
                };

                const getProfName = (prof) => {
                    if (prof === "trained") return "Trained";
                    if (prof === "expert") return "Expert";
                    if (prof === "master") return "Master";
                    if (prof === "legendary") return "Legendary";
                    return "";
                };

                if (!isMulti) {
                    let finalDC = params[bracket] || params[tier] || params.low || "??";

                    checkConfig.skills.push({
                        act: params.act || "",
                        name: params.skill || "",
                        profName: getProfName(params.prof),
                        prof: params.prof || "untrained",
                        dc: finalDC
                    });

                    buttonLabels.push(params.act || params.skill || "Skill");
                } else {
                    let i = 0;
                    while (params[`low_${i}`] || params[`high_${i}`] || params[`skill_${i}`]) {
                        let finalDC = params[`${bracket}_${i}`] || params[`${tier}_${i}`] || params[`low_${i}`] || "??";

                        checkConfig.skills.push({
                            act: params[`act_${i}`] || "",
                            name: params[`skill_${i}`] || "",
                            profName: getProfName(params[`prof_${i}`]),
                            prof: params[`prof_${i}`] || "untrained",
                            dc: finalDC
                        });

                        buttonLabels.push(params[`act_${i}`] || params[`skill_${i}`] || "Skill");
                        i++;
                    }
                }

                let uniqueLabels = [...new Set(buttonLabels)];

                let combinedText = "";
                if (uniqueLabels.length === 1) {
                    combinedText = `${uniqueLabels[0]} Check`;
                } else if (uniqueLabels.length === 2) {
                    combinedText = `${uniqueLabels[0]} or ${uniqueLabels[1]} Check`;
                } else {
                    let last = uniqueLabels.pop();
                    combinedText = `${uniqueLabels.join(", ")}, or ${last} Check`;
                }

                let encodedConfig = encodeURIComponent(JSON.stringify(checkConfig));

                span.innerHTML = `<a class="content-link wft-dc-btn" data-title="${combinedText}" data-config="${encodedConfig}" style="${wrapStyle}"><i class="fas ${checkConfig.secret ? 'fa-eye-slash' : 'fa-dice-d20'}"></i> ${combinedText}</a>`;
                span.title = `Tier: ${tier.toUpperCase()} | CP: ${cp} (${playerCount} players) | Base Level: ${baseLevel}`;
            }
            else if (params.type === "macro") {
                let macroName = params[bracket] || params[tier] || params.low;
                if (macroName) span.innerHTML = `<a class="content-link wft-macro-btn" draggable="true" data-macro="${macroName}" style="${wrapStyle}"><i class="fas fa-terminal"></i> ${macroName} (Tier ${tier.toUpperCase()})</a>`;
                else span.innerText = "[No Macro Configured]";
            }
            else if (params.type === "treasure") {
                let itemTier = (params.tier || "both").toLowerCase();
                let isActive = itemTier === "both" || itemTier === tier;

                let qty = params.qty ? `${params.qty}x ` : "";
                let displayName = params.name || "Unknown Item";
                let uuid = params.uuid || "";

                if (isActive) {
                    span.innerHTML = `<span style="font-weight: bold; margin-right: 4px;">${qty}</span><a class="content-link wft-treasure-btn" data-uuid="${uuid}" draggable="true" style="${wrapStyle}"><i class="fas fa-suitcase"></i> ${displayName}</a>`;
                } else {
                    span.style.display = "none";
                }
            }
            else if (params.type === "var") {
                let id = params.id;
                let vars = game.settings.get("wolfies-foundry-tools", "variables") || {};
                let v = vars[id];

                if (!v) {
                    span.innerHTML = `<span style="color: red; font-weight: bold;">[Variable "${id}" Not Found]</span>`;
                } else {
                    let displayVal = v.value;
                    if (v.type === "bool") displayVal = v.value ? "True" : "False";

                    span.innerHTML = `<a class="content-link wft-var-btn" data-id="${id}" style="${wrapStyle} background: #e8f4f8; border: 1px solid #7da6b3; color: #222;"><i class="fas fa-calculator" style="color: #4a8094;"></i> <strong>${v.name}:</strong> ${displayVal}</a>`;
                }
            }

            return span;
        }
    });

    CONFIG.TextEditor.enrichers.push({
        pattern: /@WFT\[type:var\|id:(.+?)\]/g,
        enricher: async (match, options) => {
            let id = match[1];
            let vars = game.settings.get("wolfies-foundry-tools", "variables") || {};
            let varData = vars[id];

            if (!varData) {
                if (game.user.isGM) {
                    let err = document.createElement("span");
                    err.style.color = "red"; err.style.fontSize = "10px"; err.innerText = `[Missing Var: ${id}]`;
                    return err;
                }
                return document.createTextNode("");
            }

            if (varData.conditions && varData.conditions.rules && varData.conditions.rules.length > 0) {
                let results = varData.conditions.rules.map(rule => {
                    let targetVar = vars[rule.varId];
                    if (!targetVar) return false;

                    let a = targetVar.value;
                    let b = rule.val;

                    if (targetVar.type === "int" || targetVar.type === "float") b = Number(b);
                    if (targetVar.type === "bool") b = (b === "true" || b === true);

                    if (rule.op === "==") return a == b;
                    if (rule.op === "!=") return a != b;
                    if (rule.op === ">=") return a >= b;
                    if (rule.op === "<=") return a <= b;
                    if (rule.op === ">") return a > b;
                    if (rule.op === "<") return a < b;
                    return false;
                });

                let isTrue = varData.conditions.logicMode === "&&"
                    ? results.every(r => r === true)
                    : results.some(r => r === true);

                if (!isTrue) return document.createTextNode("");
            }

            const span = document.createElement("span");
            span.classList.add("wft-var-display");
            span.dataset.varId = id;

            if (varData.type === "text") {
                span.innerHTML = await TextEditor.enrichHTML(varData.value, { async: true });
            } else {
                span.innerText = varData.value;
                span.style.fontWeight = "bold";
                span.style.color = "#4a8094";
                span.style.padding = "0 4px";
                span.style.background = "rgba(74, 128, 148, 0.1)";
                span.style.borderRadius = "3px";
            }

            if (game.user.isGM) {
                span.style.cursor = "pointer";
                span.title = `GM: Click to edit ${varData.name}`;
            }
            return span;
        }
    });
}